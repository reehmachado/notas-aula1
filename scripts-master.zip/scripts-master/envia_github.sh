#!/bin/bash


git add *
git commit -m "enviado por script"
git push
