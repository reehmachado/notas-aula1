#!/bin/bash

j=1

until [ $j -gt 10 ]
do
	echo $j
	j=$(($j+1))
done


