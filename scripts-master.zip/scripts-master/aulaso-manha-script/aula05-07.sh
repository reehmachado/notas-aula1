## ler e exibir  todos os arquivos do /home e

#!/bin/bahs


for j in $(ls ~)
do
	echo  "$j"
done 
