#!/bin/bash

minhaversao()
{
	echo minha versao preferida do linux e $1 
}

minhaversao "ubuntu"
minhaversao "fedora"
