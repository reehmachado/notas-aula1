#!/bin/bash

echo "o nome do script: "$0
echo "o primeiro  parametro: "$1
echo "o segundo parametro " $2
echo "o terceiro parametro: "$3
echo "todos os parametros: "$*
echo "numero de parametros" $#
